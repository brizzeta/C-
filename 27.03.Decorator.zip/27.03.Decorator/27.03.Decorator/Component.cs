﻿namespace _27._03.Decorator
{
    internal interface Component
    {
        int Attac { get; set; }
        int Speed { get; set; }
        int Health { get; set; }
        int Protection { get; set; }
        int Level { get; set; }
        void NewLevel(Component hero);
    }
}
