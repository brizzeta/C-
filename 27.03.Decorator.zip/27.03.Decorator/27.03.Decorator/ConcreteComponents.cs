﻿using System;

namespace _27._03.Decorator
{
    internal class Elf : Component
    {
        public int Attac { get; set; }
        public int Speed { get; set; }
        public int Health { get; set; }
        public int Protection { get; set; }
        public int Level { get; set; }
        public Elf() 
        {
            Attac = 15;
            Speed = 30;
            Health = 100;
            Protection = 0;
            Level = 1;
        }
        public void NewLevel(Component hero)
        {
            Console.Write("New level - ");

            Component newHero = new Elf();
            newHero = this;

            Component baseDecorator = new Human_Warrior();
        }
        public override string ToString() => $"ELF\n\nAttac - {Attac}\nSpeed - {Speed}\nHealth - {Health}\nProtection - {Protection}";
    }
    internal class Human : Component
    {
        public int Attac { get; set; }
        public int Speed { get; set; }
        public int Health { get; set; }
        public int Protection { get; set; }
        public Human()
        {
            Attac = 20;
            Speed = 20;
            Health = 150;
            Protection = 0;
        }
        public void NewLevel()
        {
            Console.Write("New level - ");
        }
        public void NewLevelChanges(BaseDecorator hero)
        {
            Attac += hero.Attac;
            Speed += hero.Speed;
            Health += hero.Health;
            Protection += hero.Protection;
        }
        public override string ToString() => $"ELF\n\nAttac - {Attac}\nSpeed - {Speed}\nHealth - {Health}\nProtection - {Protection}";
    }
}
