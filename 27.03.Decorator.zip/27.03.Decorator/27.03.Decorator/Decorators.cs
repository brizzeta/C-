﻿using System;

namespace _27._03.Decorator
{
    internal abstract class BaseDecorator : Component
    {
        protected Human hero;
        public int Attac { get; set; }
        public int Speed { get; set; }
        public int Health { get; set; }
        public int Protection { get; set; }
        public int Level { get; set; }

        public abstract void NewLevel(Component hero);
    }
    internal class Human_Warrior : BaseDecorator
    {
        //Human hero;
        //public int Attac { get; set; }
        //public int Speed { get; set; }
        //public int Health { get; set; }
        //public int Protection { get; set; }
        public Human_Warrior(Human hero)
        {
            this.hero = hero;
            Attac = 20;
            Speed = 10;
            Health = 50;
            Protection = 20;
        }
        public override void NewLevel(Component hero) {
            Console.WriteLine("Human warrior");
        }
    }
    internal class Swordsman : BaseDecorator
    {
        public Swordsman(Component hero) : base(hero)
        {
            Attac = 40;
            Speed = -10;
            Health = 50;
            Protection = 40;
        }
        public override void NewLevel()
        {
            Console.WriteLine("Swordsmanr");
        }
        public void NewLevelChanges(Human hero)
        {
            hero.NewLevel();
            NewLevel();
            hero.NewLevelChanges(new Swordsman(new Human()));
        }
    }
    internal class Archer : BaseDecorator
    {
        public Archer(Component hero) : base(hero)
        {
            Attac = 20;
            Speed = 20;
            Health = 50;
            Protection = 10;
        }
        public override void NewLevel()
        {
            Console.WriteLine("Archer");
        }
        public void NewLevelChanges(Human hero)
        {
            hero.NewLevel();
            NewLevel();
            hero.NewLevelChanges(new Archer(new Human()));
        }
    }
    internal class Rider : BaseDecorator
    {
        public Rider(Component hero) : base(hero)
        {
            Attac = -10;
            Speed = 40;
            Health = 200;
            Protection = 100;
        }
        public override void NewLevel()
        {
            Console.WriteLine("Rider");
        }
        public void NewLevelChanges(Human hero)
        {
            hero.NewLevel();
            NewLevel();
            hero.NewLevelChanges(new Rider(new Human()));
        }
    }
    internal class Elf_Warrior : BaseDecorator
    {
        public Elf_Warrior(Component hero) : base(hero)
        {
            Attac = 20;
            Speed = -10;
            Health = 100;
            Protection = 20;
        }
        public override void NewLevel()
        {
            Console.WriteLine("Elf warrior");
        }
        public void NewLevelChanges(Elf hero)
        {
            hero.NewLevel();
            NewLevel();
            hero.NewLevelChanges(new Elf_Warrior(new Elf()));
        }
    }
    internal class Magician : BaseDecorator
    {
        public Magician(Component hero) : base(hero)
        {
            Attac = 10;
            Speed = 10;
            Health = -50;
            Protection = 10;
        }
        public override void NewLevel()
        {
            Console.WriteLine("Magician");
        }
        public void NewLevelChanges(Elf hero)
        {
            hero.NewLevel();
            NewLevel();
            hero.NewLevelChanges(new Magician(new Elf()));
        }
    }
    internal class Crossbowman : BaseDecorator
    {
        public Crossbowman(Component hero) : base(hero)
        {
            Attac = 20;
            Speed = 10;
            Health = -50;
            Protection = 10;
        }
        public override void NewLevel()
        {
            Console.WriteLine("Crossbowman");
        }
        public void NewLevelChanges(Elf hero)
        {
            hero.NewLevel();
            NewLevel();
            hero.NewLevelChanges(new Crossbowman(new Elf()));
        }
    }
    internal class EvilMage : BaseDecorator
    {
        public EvilMage(Component hero) : base(hero)
        {
            Attac = 70;
            Speed = 20;
            Health = 0;
            Protection = 0;
        }
        public override void NewLevel()
        {
            Console.WriteLine("Evil mage");
        }
        public void NewLevelChanges(Elf hero)
        {
            hero.NewLevel();
            NewLevel();
            hero.NewLevelChanges(new EvilMage(new Elf()));
        }
    }
    internal class GoodMage : BaseDecorator
    {
        public GoodMage(Component hero) : base(hero)
        {
            Attac = 50;
            Speed = 30;
            Health = 100;
            Protection = 30;
        }
        public override void NewLevel()
        {
            Console.WriteLine("Good mage");
        }
        public void NewLevelChanges(Elf hero)
        {
            hero.NewLevel();
            NewLevel();
            hero.NewLevelChanges(new GoodMage(new Elf()));
        }
    }
}
