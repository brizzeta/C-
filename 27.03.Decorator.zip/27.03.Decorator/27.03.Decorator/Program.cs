﻿using System;

namespace _27._03.Decorator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Human human = new Human();
            Console.WriteLine(human.ToString());

            BaseDecorator warrior = new Human_Warrior(human);
            warrior.NewLevelChanges(human);

            Console.WriteLine(human.ToString());
        }
    }
}
